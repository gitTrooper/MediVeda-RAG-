---
title: MedVedaReportAnalysis
emoji: 📊
colorFrom: indigo
colorTo: yellow
sdk: gradio
sdk_version: 5.23.2
app_file: app.py
pinned: false
license: apache-2.0
short_description: This space is used for medical report analysis
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
